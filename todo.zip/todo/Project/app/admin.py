from django.contrib import admin
from .models import tasksheet
# Register your models here.
admin.site.register(tasksheet)

class tasksheetAdmin(admin.ModelAdmin):
    list_display=['id','task']