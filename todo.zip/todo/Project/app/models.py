from django.db import models

# Create your models here.
class tasksheet(models.Model):
    task=models.TextField(max_length=122)

    def __str__(self) -> str:
        return self.task 