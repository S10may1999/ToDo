from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="Home"),
    path('add_task/',views.Add_task,name="Task"),
    path('update/<int:id>',views.update,name="Update"),
    path('complete/<int:id>',views.completed,name="Finish")
]