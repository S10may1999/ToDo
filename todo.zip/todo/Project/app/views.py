from django.shortcuts import render,redirect
from .models import tasksheet

# Create your views here.
def index(request):
    data=tasksheet.objects.all()
    context={'name':data}
    return render(request,'index.html',context)

def Add_task(request):
    if request.method=="POST":
        task=request.POST['task']
        taskdata=tasksheet(task=task)
        taskdata.save()
        return redirect('Home')
    return render(request,'taskadd.html')

def update(request,id):
    Updateddata=tasksheet.objects.get(id=id)
    if request.method=="POST":
        task=request.POST["task"]
        Updateddata.task=task
        Updateddata.save()
        return redirect('Home')

    
    context={'name2':Updateddata}
    return render(request,'update.html',context)

def completed(request,id):
    Updateddata=tasksheet.objects.get(id=id)
    Updateddata.delete()
    return redirect('Home')